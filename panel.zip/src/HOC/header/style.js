import Styled from "styled-components";


const StyledHeader = Styled.header`
    padding:10px;
    background-color:#f5f5f5;
    margin-right:18vw;
`;

export { StyledHeader };
