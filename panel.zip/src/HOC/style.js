
import Styled from 'styled-components';
 
const StyledContainer = Styled.div`
    margin-right:18vw;
    padding: 4rem;
`;
 
export {StyledContainer};