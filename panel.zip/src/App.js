import React from 'react';
import MainRouter from './router';
import "./App.css";
import "./assets/font/iransans/webFonts/css/fontiran.css";

function App() {
  return (
    <MainRouter />
  );
}

export default App;
