import Styled from 'styled-components';
import { Form } from 'antd';



const StyledForm = Styled(Form)`
    .ant-form-item-label{
        width: 30%;
    }
`;
 
export {StyledForm};