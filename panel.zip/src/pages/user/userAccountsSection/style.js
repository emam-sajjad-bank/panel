import Styled from 'styled-components';
 
const StyledColActions = Styled.div`
    display:flex;
    & > button{
        margin:0 5px;
    }
`;
 
export {StyledColActions};