import SingleUpload from './singleUpload';




export {SingleUpload};